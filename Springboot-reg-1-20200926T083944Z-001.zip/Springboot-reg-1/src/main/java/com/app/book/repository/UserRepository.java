package com.app.book.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.app.book.model.User;

@Repository
public interface UserRepository extends MongoRepository<User, Long>{

}



