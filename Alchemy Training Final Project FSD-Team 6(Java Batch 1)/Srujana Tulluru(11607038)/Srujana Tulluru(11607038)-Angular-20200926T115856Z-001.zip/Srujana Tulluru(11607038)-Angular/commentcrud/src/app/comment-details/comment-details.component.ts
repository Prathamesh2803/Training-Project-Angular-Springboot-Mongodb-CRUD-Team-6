import { Component, OnInit } from '@angular/core';
import { Comment } from '../comment';
import { CommentService } from '../comment.service';
import { CommentListComponent } from '../comment-list/comment-list.component';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-comment-details',
  templateUrl: './comment-details.component.html',
  styleUrls: ['./comment-details.component.css']
})
export class CommentDetailsComponent implements OnInit {
  id: number;
  comment: Comment;

  constructor(private route: ActivatedRoute,private router: Router,
    private commentService: CommentService) { }

  ngOnInit(): void {
    this.comment = new Comment();

    this.id = this.route.snapshot.params['id'];
    
    this.commentService.getComment(this.id)
      .subscribe(data => {
        console.log(data)
        this.comment = data;
      }, error => console.log(error));
  }

  list(){
    this.router.navigate(['comments']);
  }
  }
