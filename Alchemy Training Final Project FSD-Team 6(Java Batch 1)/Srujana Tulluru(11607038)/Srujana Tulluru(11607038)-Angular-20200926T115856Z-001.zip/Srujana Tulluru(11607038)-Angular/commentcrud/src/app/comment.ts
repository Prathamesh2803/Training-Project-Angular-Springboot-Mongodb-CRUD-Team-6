export class Comment {
    id: number;
    comment: string;
    username: string;
    bookname: string;
    active: boolean;
}