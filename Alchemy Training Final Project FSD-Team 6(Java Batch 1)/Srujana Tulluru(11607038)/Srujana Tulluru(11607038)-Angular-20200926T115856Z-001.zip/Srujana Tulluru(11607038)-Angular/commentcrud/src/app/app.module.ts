import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CreateCommentComponent } from './create-comment/create-comment.component';
import { CommentDetailsComponent } from './comment-details/comment-details.component';
import { CommentListComponent } from './comment-list/comment-list.component';
import { HttpClientModule } from '@angular/common/http';
import { UpdateCommentComponent } from './update-comment/update-comment.component';

@NgModule({
  declarations: [
    AppComponent,
    CreateCommentComponent,
    CommentDetailsComponent,
    CommentListComponent,
    UpdateCommentComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
