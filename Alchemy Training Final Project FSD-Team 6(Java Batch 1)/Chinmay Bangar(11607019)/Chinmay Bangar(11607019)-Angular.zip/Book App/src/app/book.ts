export class Book {
  id: number;
  name: string;
  author: string;
  description: string;
  active: boolean;
}
